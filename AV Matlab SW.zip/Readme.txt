This directory contains the following m-files:
-- allan.m: Implements the Allan variance computation
-- ASD_plot_generation.m: Given parameters that define a state-space model for the sensor stochastic errors, this function computes (1) the state-space model, (2) simulates that model to produce a stochastic error sequence, (3) computes and plots the ASD.
-- opt_NBK_search.m: Implements an optimization based approach to selecting the state-space model parameters for the problem defined in Section VIII.B of the paper. 

The following data files are important:
-- ASD_Marble_slab.mat: This data file is output by "opt_NBK_search.m" to save repeated computation of the ASD, which is slow. The m-file contains a flag "COMPUTE_ASD". This flag should be set to 1 the first time the m-file is run to creat this file. After that, it can be reset to 0 to save computations.   
-- data_Z.mat: This file is both created and read by ASD_plot_generation.m.  This m-file contains a flag "rerun". Set the flag to 1 the first time that you run the code, and any time thereafter when you want new data, to simulate the model and creat the file.  Once you have the file, you can reset the flag to 0 to save computation time. Note that if you change the sate-space error model, you need to set the flag to generate new data for the new model. 
-- parsed_isolated_marble_data.mat: This is data from a motion isolated IMU. It is used by "opt_NBK_search.m". 

