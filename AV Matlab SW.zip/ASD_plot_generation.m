clc;
clear all;

%%% This script has below stated functionality:
%%% (1) Given a continuous time error model, it computes a 
%%% discrete-time equivalent state space-model.
%%% (2) Given that discrete-time model, it produces a
%%% stochastic error sequence.
%%% (3) Given a sequence of stochastic errors, computes and
%%% plots the Allan Variance data,

%%%-------------------------%%%
%%%--------Task 1-----------%%%

%%% Sensor sampling frequency
Fs=100;
dT=1/Fs; 

%%% Data length
L_n=10000000;

%%% IMU time stamp
imu_t=0:dT:(L_n-1)*dT;

%%% NAV1000 IMU accelerometer z axis
%%% Correlation time in sec
Tc=50;

%%% Time constant parameter
mu_b=1/Tc;

%%% Random walk parameter, N (m/sec.sqrt(sec))
N=3.3e-3;

%%% Bias instability parameter, B (m/sec.sec)
B=6e-4;

%%% Rate random walk parameter, K (m/sec.sec^(3/2))
K=1.2e-4;

%%% Continuous time state space model using eqn. (40)
A_t=[-mu_b 0;
    0 0];
B_t=[1 0;
    0 1];
C_t=[1 1];

%%% Continuous time PSD parameters from eqn. (38)
%%% PSD parameter for bias instability
Qb=(2*B^2*log(2))/(pi*0.4365^2*Tc);

%%% PSD parameter for rate random walk from eqn. (23)
Qk=K^2;

%%% PSD parameter for random walk process noise from eqn. (20)
Qn=N^2;

%%% Process noise for noise propagation using eqn. (41) 
Q=[Qb 0;
   0 Qk];

%%% Continuous to discrete transformation using eqn. (4.114) of [3]
A_c(1:2,1:2) = -1*A_t;
A_c(1:2,3:4) = B_t*Q*B_t';
A_c(3:4,3:4) = A_t';

A_c=A_c*dT;
B_c=expm(A_c);

%%% From eqn. (4.115) of [3]
Phi=B_c(3:4,3:4);

%%% From eqn. (4.116) of [3]
Qd=B_c(1:2,3:4);

%%% Discrete time bias instability driving noise
Qbk=Qd(1,1);

%%% Discsrete time rate random walk process noise
Qkk=Qd(2,2);

%%% Discsrete time random walk process noise using eqn. (60)
Qnk=Qn*Fs;

%%%-------------------------%%%
%%%--------Task 2-----------%%%

%%% Initial error state
Z_b=[0;0];

%%% There are two modes to run: 
%%% rerun = 0 (Load the previously saved generated data)
%%% rerun = 1 (Generate data using given parameters)
%%% Set rerun to 1 the first time that you run the code. 
rerun = 1;
if rerun == 1
    for ij=1:L_n
        %%% Generate random noise 
        n_b=sqrt(Qbk)*randn(1,1);
        n_k=sqrt(Qkk)*randn(1,1);
        n_n=sqrt(Qnk)*randn(1,1);
        %%% From eqn. (42) 
        Z_b=Phi*Z_b+[n_b;n_k];
        %%% From eqn. (43) 
        Z(ij,1)=Z_b(1)+Z_b(2)+n_n;
    end
    save data_Z.mat Z
else
    load data_Z.mat
end

%%%-------------------------%%%
%%%--------Task 3-----------%%%

%%% Computing Allan variance plot
data.freq=Z;
data.rate=Fs;
% Define the cluster times
tau1=0:dT:(10-1)*dT;
tau1=[0.01,0.02,0.03,0.04,0.05,0.06,0.07,0.08,0.09];
tau2=10*dT:10*dT:90*dT;
tau3=100*dT:100*dT:900*dT;
tau4=1000*dT:1000*dT:9000*dT;
tau5=10000*dT:10000*dT:90000*dT;
tau6=100000*dT:100000*dT:900000*dT;
tau7=1000000*dT:1000000*dT:4000000*dT;
tau=[tau1 tau2 tau3 tau4 tau5 tau6 tau7]';
% Compute AV
[avar]=allan(data, tau);

%%% Allan SD is in sig2 field of avar structure
allan_sd=avar.sig2;
figure
loglog(tau,allan_sd,'b.','LineWidth',2)
xlabel('Cluster time (sec)','FontSize',14)
ylabel('Allan SD (m/s^2)','FontSize',14)
ylim([1e-4 1e-1]);
grid on;
title('ASD plot from generated data')





